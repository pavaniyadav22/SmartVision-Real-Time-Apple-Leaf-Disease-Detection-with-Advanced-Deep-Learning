
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Icons } from '../constants';

interface CameraViewProps {
  onCapture: (base64: string) => void;
  isProcessing: boolean;
}

const CameraView: React.FC<CameraViewProps> = ({ onCapture, isProcessing }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isActive, setIsActive] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment', width: 1280, height: 720 } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsActive(true);
        setError(null);
      }
    } catch (err) {
      setError("Unable to access camera. Please ensure permissions are granted.");
      console.error(err);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsActive(false);
    }
  };

  const captureFrame = useCallback(() => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const base64 = canvas.toDataURL('image/jpeg', 0.8);
        onCapture(base64);
      }
    }
  }, [onCapture]);

  useEffect(() => {
    return () => stopCamera();
  }, []);

  return (
    <div className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-xl border-4 border-white/10 group">
      {!isActive ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-6 text-center bg-gradient-to-br from-green-900/40 to-emerald-900/60">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mb-4">
            <Icons.Camera />
          </div>
          <h3 className="text-xl font-semibold mb-2">Live Diagnosis Mode</h3>
          <p className="text-white/70 mb-6 max-w-xs">Align the apple leaf within the center of the frame for optimal detection.</p>
          <button
            onClick={startCamera}
            className="px-8 py-3 bg-emerald-500 hover:bg-emerald-400 text-white rounded-full font-bold transition-all transform hover:scale-105"
          >
            Start Camera
          </button>
          {error && <p className="mt-4 text-red-300 text-sm">{error}</p>}
        </div>
      ) : (
        <>
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
          
          {/* Viewfinder overlay */}
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
             <div className="w-64 h-64 border-2 border-white/50 border-dashed rounded-3xl"></div>
          </div>

          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4">
            <button
              onClick={stopCamera}
              className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white/30 transition-colors"
            >
              ✕
            </button>
            <button
              disabled={isProcessing}
              onClick={captureFrame}
              className={`w-20 h-20 bg-white rounded-full flex items-center justify-center text-emerald-600 shadow-2xl transition-all active:scale-90 ${isProcessing ? 'opacity-50' : 'hover:scale-110'}`}
            >
              {isProcessing ? (
                <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <div className="w-16 h-16 border-2 border-emerald-100 rounded-full flex items-center justify-center">
                   <div className="w-14 h-14 bg-emerald-500 rounded-full"></div>
                </div>
              )}
            </button>
          </div>
        </>
      )}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};

export default CameraView;
