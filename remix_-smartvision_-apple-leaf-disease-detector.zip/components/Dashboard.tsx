
import React from 'react';
import { MODEL_METRICS } from '../constants';

const Dashboard: React.FC = () => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <p className="text-slate-500 text-xs font-semibold uppercase mb-1">Model Accuracy</p>
        <p className="text-2xl font-bold text-emerald-600">{MODEL_METRICS.accuracy}%</p>
      </div>
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <p className="text-slate-500 text-xs font-semibold uppercase mb-1">Inference Time</p>
        <p className="text-2xl font-bold text-blue-600">{MODEL_METRICS.inferenceTime}</p>
      </div>
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <p className="text-slate-500 text-xs font-semibold uppercase mb-1">Inference Speed</p>
        <p className="text-2xl font-bold text-amber-600">{MODEL_METRICS.fps} FPS</p>
      </div>
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <p className="text-slate-500 text-xs font-semibold uppercase mb-1">F1-Score</p>
        <p className="text-2xl font-bold text-purple-600">{MODEL_METRICS.f1Score}%</p>
      </div>
    </div>
  );
};

export default Dashboard;
