
import React from 'react';
import { AnalysisResult, SeverityLevel, DiseaseType } from '../types';

interface ResultCardProps {
  result: AnalysisResult;
  image: string;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, image }) => {
  const getSeverityColor = (level: SeverityLevel) => {
    switch (level) {
      case SeverityLevel.LOW: return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case SeverityLevel.MEDIUM: return 'bg-orange-100 text-orange-800 border-orange-200';
      case SeverityLevel.HIGH: return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-green-100 text-green-800 border-green-200';
    }
  };

  const getConfidenceColor = (score: number) => {
    if (score > 90) return 'text-emerald-600';
    if (score > 70) return 'text-amber-600';
    return 'text-red-600';
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row">
        <div className="md:w-1/3">
          <img src={image} alt="Analyzed Leaf" className="w-full h-full object-cover min-h-[200px]" />
        </div>
        <div className="p-6 md:w-2/3 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-2xl font-bold text-slate-800">
                {result.disease === DiseaseType.HEALTHY ? "Healthy Leaf" : result.disease}
              </h3>
              <span className={`px-3 py-1 rounded-full text-xs font-bold border ${getSeverityColor(result.severity)}`}>
                {result.severity.toUpperCase()} SEVERITY
              </span>
            </div>
            
            <div className="mb-4">
              <span className={`text-sm font-semibold ${getConfidenceColor(result.confidence)}`}>
                {result.confidence}% Confidence Score
              </span>
              <div className="w-full bg-slate-100 h-2 rounded-full mt-1">
                <div 
                  className={`h-full rounded-full transition-all duration-1000 ${result.confidence > 70 ? 'bg-emerald-500' : 'bg-amber-500'}`} 
                  style={{ width: `${result.confidence}%` }}
                ></div>
              </div>
            </div>

            <p className="text-slate-600 text-sm italic mb-4 leading-relaxed">
              &quot;{result.description}&quot;
            </p>
          </div>

          <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100">
            <h4 className="text-emerald-800 font-bold text-sm mb-1 uppercase tracking-wider">Action Plan</h4>
            <p className="text-emerald-700 text-sm leading-relaxed">{result.recommendation}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultCard;
