
import { GoogleGenAI, Type } from "@google/genai";
import { DiseaseType, SeverityLevel, AnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    disease: {
      type: Type.STRING,
      description: "Must be one of: Healthy, Apple Scab, Black Rot, Cedar Apple Rust",
    },
    severity: {
      type: Type.STRING,
      description: "Must be one of: Low, Medium, High, None",
    },
    confidence: {
      type: Type.NUMBER,
      description: "Confidence percentage (0-100)",
    },
    description: {
      type: Type.STRING,
      description: "Short scientific description of what is seen on the leaf.",
    },
    recommendation: {
      type: Type.STRING,
      description: "Actionable agricultural advice for the farmer.",
    },
  },
  required: ["disease", "severity", "confidence", "description", "recommendation"],
};

export async function analyzeLeaf(base64Image: string): Promise<AnalysisResult> {
  const model = "gemini-3-flash-preview";
  
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Image.split(",")[1] || base64Image,
          },
        },
        {
          text: `You are the SmartVision Apple Leaf Disease Analysis model. 
          Analyze this leaf image and identify if it has: Healthy, Apple Scab, Black Rot, or Cedar Apple Rust.
          Estimate the severity (Low, Medium, High) based on lesion coverage.
          Provide a confidence score.
          Return the data in the specified JSON format.`,
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: ANALYSIS_SCHEMA,
    },
  });

  const rawJson = JSON.parse(response.text || "{}");
  
  return {
    disease: rawJson.disease as DiseaseType,
    severity: rawJson.severity as SeverityLevel,
    confidence: rawJson.confidence || 0,
    description: rawJson.description || "No description available.",
    recommendation: rawJson.recommendation || "No recommendation available.",
    timestamp: new Date().toISOString(),
  };
}
